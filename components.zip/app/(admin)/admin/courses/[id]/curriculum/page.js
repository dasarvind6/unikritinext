'use client';
import { useState, useMemo } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { 
  Container, 
  Row, 
  Col, 
  Button, 
  Card, 
  Spinner, 
  Alert, 
  Modal, 
  Form, 
  ListGroup 
} from 'react-bootstrap';
import { 
  useGetAdminCourseSectionsQuery, 
  useCreateAdminCourseSectionMutation, 
  useUpdateAdminSectionMutation, 
  useDeleteAdminSectionMutation,
  useReorderAdminCourseSectionsMutation
} from '@/redux/api/apiSlice';
import { 
  FiPlus, 
  FiEdit3, 
  FiTrash2, 
  FiArrowUp,
  FiArrowDown,
  FiCheck, 
  FiX, 
  FiLayers,
  FiBook,
  FiArrowLeft
} from 'react-icons/fi';
import toast from 'react-hot-toast';

export default function AdminCourseCurriculumPage() {
  const { id: courseId } = useParams();
  const router = useRouter();
  const { data: sectionsData, isLoading, isError, error } = useGetAdminCourseSectionsQuery(courseId);
  const [createAdminCourseSection, { isLoading: isCreating }] = useCreateAdminCourseSectionMutation();
  const [updateSection, { isLoading: isUpdating }] = useUpdateAdminSectionMutation();
  const [deleteSection, { isLoading: isDeleting }] = useDeleteAdminSectionMutation();
  const [reorderSections] = useReorderAdminCourseSectionsMutation();

  const [showModal, setShowModal] = useState(false);
  const [editingSection, setEditingSection] = useState(null);
  const [sectionTitle, setSectionTitle] = useState('');

  const sections = useMemo(() => sectionsData?.data || [], [sectionsData]);

  const handleOpenModal = (section = null) => {
    if (section) {
      setEditingSection(section);
      setSectionTitle(section.title);
    } else {
      setEditingSection(null);
      setSectionTitle('');
    }
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!sectionTitle.trim()) {
      toast.error('Section title is required');
      return;
    }

    try {
      if (editingSection) {
        await updateSection({ 
          courseId, 
          sectionId: editingSection._id, 
          title: sectionTitle 
        }).unwrap();
        toast.success('Section updated!');
      } else {
        await createAdminCourseSection({ 
          courseId, 
          title: sectionTitle, 
          order: sections.length 
        }).unwrap();
        toast.success('Section created!');
      }
      setShowModal(false);
    } catch (err) {
      toast.error(err?.data?.message || 'Failed to save section');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this section?')) return;
    try {
      await deleteSection({ courseId, sectionId: id }).unwrap();
      toast.success('Section deleted!');
    } catch (err) {
      toast.error(err?.data?.message || 'Failed to delete section');
    }
  };

  const handleMove = async (index, direction) => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= sections.length) return;

    const updatedSections = [...sections];
    const [moved] = updatedSections.splice(index, 1);
    updatedSections.splice(newIndex, 0, moved);

    const elements = updatedSections.map((s, i) => ({ _id: s._id, order: i }));

    try {
      await reorderSections({ courseId, elements }).unwrap();
      toast.success('Order updated!');
    } catch (err) {
      toast.error('Failed to reorder sections');
    }
  };

  if (isLoading) {
    return (
      <Container className="py-5 text-center">
        <Spinner animation="border" variant="primary" />
        <p className="mt-3 text-muted">Loading curriculum...</p>
      </Container>
    );
  }

  return (
    <Container className="py-4">
      <div className="mb-4">
        <Button 
          variant="link" 
          className="p-0 text-decoration-none text-muted mb-3 d-flex align-items-center gap-1"
          onClick={() => router.back()}
        >
          <FiArrowLeft /> Back to Course
        </Button>
        <div className="d-flex justify-content-between align-items-center">
          <div>
            <h2 className="fw-bold mb-1">Manage Curriculum (Admin)</h2>
            <p className="text-muted mb-0">Academic structure of the course.</p>
          </div>
          <Button 
            variant="primary" 
            className="d-flex align-items-center gap-2 shadow-sm"
            onClick={() => handleOpenModal()}
          >
            <FiPlus /> Add Section
          </Button>
        </div>
      </div>
 
      {isError && <Alert variant="danger" className="mb-4 border-0 shadow-sm">{error?.data?.message || 'Error loading curriculum'}</Alert>}

      <div className="curriculum-list">
        {sections.length > 0 ? (
          sections.map((section, index) => (
            <Card key={section._id} className="mb-3 border-0 shadow-sm overflow-hidden">
              <Card.Header className="bg-white py-3 border-0 d-flex align-items-center justify-content-between">
                <div className="d-flex align-items-center gap-3">
                  <div className="section-order badge bg-light text-dark border p-2 rounded-3">
                    <FiLayers className="me-1 opacity-50" /> {index + 1}
                  </div>
                  <div>
                    <h5 className="mb-0 fw-bold">{section.title}</h5>
                  </div>
                </div>
                <div className="d-flex align-items-center gap-2">
                  <div className="d-flex gap-1 me-2 border-end pe-2">
                    <Button 
                      variant="link" 
                      className={`p-1 text-muted ${index === 0 ? 'opacity-25' : 'hover-primary'}`}
                      disabled={index === 0}
                      onClick={() => handleMove(index, 'up')}
                    >
                      <FiArrowUp />
                    </Button>
                    <Button 
                      variant="link" 
                      className={`p-1 text-muted ${index === sections.length - 1 ? 'opacity-25' : 'hover-primary'}`}
                      disabled={index === sections.length - 1}
                      onClick={() => handleMove(index, 'down')}
                    >
                      <FiArrowDown />
                    </Button>
                  </div>
                  <Button 
                    variant="link" 
                    className="p-1 text-muted hover-primary"
                    onClick={() => handleOpenModal(section)}
                  >
                    <FiEdit3 />
                  </Button>
                  <Button 
                    variant="link" 
                    className="p-1 text-muted hover-danger"
                    onClick={() => handleDelete(section._id)}
                  >
                    <FiTrash2 />
                  </Button>
                </div>
              </Card.Header>
              <Card.Body className="bg-light-gray p-0">
                <div className="p-4 text-center border-top">
                  <div className="text-muted small mb-0">
                    <FiBook className="me-1" /> Admin view: Lessons management restricted to curriculum structure.
                  </div>
                </div>
              </Card.Body>
            </Card>
          ))
        ) : (
          <div className="text-center py-5 bg-white rounded-3 shadow-sm border border-dashed text-muted">
            <FiLayers size={48} className="mb-3 opacity-25" />
            <h4 className="fw-bold">No Sections Yet</h4>
            <p>Admin can add sections to help instructors get started.</p>
            <Button variant="primary" onClick={() => handleOpenModal()}>
              <FiPlus className="me-1" /> Add First Section
            </Button>
          </div>
        )}
      </div>

      <Modal show={showModal} onHide={() => setShowModal(false)} centered>
        <Modal.Header closeButton className="border-0">
          <Modal.Title className="fw-bold">{editingSection ? 'Edit Section' : 'Add Section'}</Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSubmit}>
          <Modal.Body className="pt-0">
            <Form.Group>
              <Form.Label className="small fw-bold text-muted text-uppercase">Section Title</Form.Label>
              <Form.Control 
                type="text" 
                placeholder="e.g. Introduction to LMS" 
                value={sectionTitle}
                onChange={(e) => setSectionTitle(e.target.value)}
                autoFocus
              />
            </Form.Group>
          </Modal.Body>
          <Modal.Footer className="border-0">
            <Button variant="light" onClick={() => setShowModal(false)}>Cancel</Button>
            <Button variant="primary" type="submit" disabled={isCreating || isUpdating} className="px-4">
              {isCreating || isUpdating ? <Spinner size="sm" /> : editingSection ? 'Update Section' : 'Create Section'}
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>

      <style jsx global>{`
        .bg-light-gray { background-color: #fcfcfc; }
        .hover-primary:hover { color: var(--bs-primary) !important; }
        .hover-danger:hover { color: var(--bs-danger) !important; }
        .border-dashed { border-style: dashed !important; border-width: 2px !important; }
      `}</style>
    </Container>
  );
}
